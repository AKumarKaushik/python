
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db import SessionLocal
from app.models.user import User
from app.schemas.user import UserCreate, Token
from app.core.security import hash_password, verify_password, create_token

router = APIRouter()

async def get_db():
    async with SessionLocal() as s:
        yield s

@router.post("/register")
async def register(data: UserCreate, db: AsyncSession = Depends(get_db)):
    user = User(
        email=data.email,
        password_hash=hash_password(data.password),
        role=data.role,
        name=data.name
    )
    db.add(user)
    await db.commit()
    return {"message": "registered"}

@router.post("/login", response_model=Token)
async def login(data: UserCreate, db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(User).where(User.email == data.email))
    user = res.scalar_one_or_none()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(401, "invalid credentials")
    token = create_token({"sub": str(user.id), "role": user.role})
    return {"access_token": token}

@router.post("/forgot-password")
async def forgot():
    return {"message": "mock password reset flow"}
