
from fastapi import FastAPI
from app.api import auth, doctors, appointments

app = FastAPI(title="Doctor Appointment API")

app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(doctors.router, tags=["Doctors"])
app.include_router(appointments.router, tags=["Appointments"])
