
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db import SessionLocal
from app.models.appointment import Appointment
from app.schemas.appointment import AppointmentCreate

router = APIRouter()

async def get_db():
    async with SessionLocal() as s:
        yield s

@router.post("/appointments")
async def book(data: AppointmentCreate, db: AsyncSession = Depends(get_db)):
    existing = await db.execute(
        select(Appointment).where(
            Appointment.doctor_id == data.doctor_id,
            Appointment.start_time == data.start_time
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(400, "Slot already booked")
    appt = Appointment(**data.dict(), patient_id=1)
    db.add(appt)
    await db.commit()
    return {"message": "appointment booked"}
