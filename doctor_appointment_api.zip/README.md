
# Doctor Appointment API

Production-ready REST API for managing doctor appointments with JWT authentication and RBAC.

## Tech Stack
- Python 3.12
- FastAPI
- SQLAlchemy Async
- PostgreSQL
- JWT (python-jose)
- Pytest
- Docker Compose

## Setup
```bash
docker-compose up --build
```

API available at http://localhost:8000  
Swagger docs at http://localhost:8000/docs

## Authentication & RBAC
- JWT-based authentication
- Roles: DOCTOR, PATIENT
- Role enforced using FastAPI dependencies
- Passwords hashed with bcrypt

## Key Design Notes
- Service + Repository pattern
- Async DB access
- Double-booking prevented at service + DB level
