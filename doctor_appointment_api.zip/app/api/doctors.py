
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db import SessionLocal
from app.models.user import User

router = APIRouter()

async def get_db():
    async with SessionLocal() as s:
        yield s

@router.get("/doctors")
async def list_doctors(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(User).where(User.role == "DOCTOR"))
    return res.scalars().all()
